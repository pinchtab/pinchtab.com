---
name: create-issue-with-images
description: "Use this skill to create a GitHub issue and attach screenshots/images/videos to it or to a pull request via PinchTab browser automation — including the headed→headless profile handoff, the synthetic file-drop needed on issues (no automatable file input), and the direct `pinchtab upload` path that works on PRs (classic editor). Triggers on: create a GitHub issue with a screenshot, attach an annotated screenshot to an issue/PR, post an image to issue #N or PR #N, headless image upload to GitHub."
argument-hint: "@<github-account> [owner/repo]"
metadata:
  openclaw:
    requires:
      bins:
        - pinchtab
        - python3
    homepage: https://github.com/pinchtab/pinchtab
---

# Create a GitHub Issue with Images (PinchTab)

Create a GitHub issue and attach one or more images to it with PinchTab. The hard
part is **attaching the image**: GitHub's React editor has no persistent
`<input type="file">` (its "add files" control opens a native OS picker that
automation can't drive), so `pinchtab upload` has nothing to target. This skill
uploads by synthesizing a **file-drop** event instead.

Prereqs: `security.allowEvaluate: true`, `github.com` (and the screenshot's
host) in `security.allowedDomains`. See **Bootstrap** below for getting the
right instance up; after that, all commands assume a session is exported:
```bash
export PINCHTAB_SESSION=$(pinchtab session create --agent-id gh)
```

## Inputs to pin down first

The skill can be invoked with arguments:
`/create-issue-with-images @<account> [owner/repo]` — e.g.
`/create-issue-with-images @pinchtabdev pinchtab/pinchtab.com`. The first
argument (leading `@` optional, strip it) is the **GitHub account** to post as;
it selects the `gh-<account>` profile and is the expected login in Preflight.
The second, if given, is the target repo.

Anything not supplied as an argument, confirm with the user before acting
(creating an issue is an outward-facing write action):

| Input | Example | Notes |
|-------|---------|-------|
| **Repo** (`account/project`) | `pinchtab/pinchtab.com` | Where the issue is posted. |
| **GitHub account** to post as | `pinchtabdev` | Used to verify the right identity is signed in. |
| **Title** / body | `update the links` | |
| **Image(s)** | annotated screenshot | What to capture and where from. |
| **Where** | new issue body, or a comment | This skill posts to a comment by default. |
| **Target** | new issue, existing issue `#N`, or PR `#N` | Existing issue → **skip step 1** of the Minimal path. PR → use the **PR path** below (simpler: real file input). |

If any of these are missing from the request, **ask — don't guess**. Repo,
account, and new-vs-existing issue are the ones that cause real damage when
assumed wrong.

## Bootstrap: instance & mode

Never assume the right instance is up. Check first:

```bash
pinchtab instances --json   # per instance: id, profileName, mode, status, port
```

Decision rule (mode is derivable — don't ask the user):

- **Instance running on profile `gh-<account>`** → reuse it. Create a session
  and go to Preflight to verify the login.
- **Instance running on any other profile** (especially the user's personal
  `default` profile) → do **not** use it for GitHub posting. Start a dedicated
  one (below). Other instances can stay running; each holds only its own
  profile's lock.
- **Nothing running** → start one:
  ```bash
  pinchtab instance start --profile gh-<account> --mode headless
  ```
  A profile that doesn't exist yet is created on first start.

**Headless is the default working mode.** Headed is only for the one-time
sign-in (Preflight step 3); after the user has logged in, stop the headed
instance and relaunch headless on the same profile:

```bash
pinchtab instance stop <inst-id>     # id from `pinchtab instances` — releases the profile lock
pinchtab instance start --profile gh-<account> --mode headless
```

## Preflight: profile & sign-in (conditional)

Each GitHub account gets its **own dedicated PinchTab profile** — never the
personal browsing profile. Only sign in headed if no profile is already logged in
as the target account.

1. **Check the current session's account — pure pinchtab, no script.** The
   signed-in login is exposed on any repo/issue page as a `@<login>'s profile`
   link:
   ```bash
   pinchtab nav "https://github.com/$REPO" --snap | grep "'s profile"
   #   e30:link "@pinchtabdev's profile"   -> signed in as pinchtabdev
   #   (no match / a "Sign in" link)       -> anonymous
   ```
   (Fallback if the snap is noisy: `pinchtab eval` on
   `document.querySelector('meta[name="user-login"]').content`.)
2. **If it matches** → proceed, the profile is reusable.
3. **If it is anonymous or a different login** → there is no signed-in profile
   for account X. Advise the user to create a dedicated profile and sign in once,
   **headed**:
   ```bash
   # dedicated, per-account profile — name it after the account
   pinchtab instance start --profile gh-<account> --mode headed
   ```
   (No `--browser` flag exists — the browser build comes from the server
   config; check with `pinchtab config show`.)
   Then have the **user** log into GitHub as account X in that headed window
   (do not automate credential entry). Re-run the check in step 1 to confirm.
   The login persists in that profile's cookies for reuse.

## Minimal path

```bash
REPO="pinchtab/pinchtab.com"; TITLE="update the links"

# 1. Create the issue
pinchtab nav "https://github.com/$REPO/issues/new" --snap
pinchtab fill 'text:Add a title' "$TITLE"          # or the "Add a title" textbox ref
pinchtab find "Create issue submit button" --ref-only   # verify it's the bottom "Create" button, not "Create new..."
pinchtab click <create-ref> --wait-nav             # or: pinchtab press 'Meta+Enter'
pinchtab url                                        # -> https://github.com/$REPO/issues/<N>  (record it)

# 2. Capture the image (annotated = numbered ref-box overlay)
pinchtab nav "https://pinchtab.com/docs" --snap
pinchtab screenshot --annotate -o /tmp/shot.png     # add --scale 0.5 for very large pages

# 3. Attach to a comment on the issue — pinchtab only (see "Attaching" below)
pinchtab nav "https://github.com/$REPO/issues/<N>" --snap
pinchtab scroll 3000                                 # bring the comment box into view (it is lazy-loaded)
IMG=/tmp/shot.png; B64=$(base64 < "$IMG" | tr -d '\n')
pinchtab eval "(async () => {
  const arr = Uint8Array.from(atob('$B64'), c => c.charCodeAt(0));
  const dt = new DataTransfer();
  dt.items.add(new File([arr], 'shot.png', { type: 'image/png' }));
  const ta = document.querySelector('textarea[placeholder=\"Use Markdown to format your comment\"]');
  for (const t of ['dragenter','dragover','drop'])
    ta.dispatchEvent(new DragEvent(t, { bubbles:true, cancelable:true, dataTransfer:dt }));
  return 'dropped';
})()" --await-promise
# wait for GitHub to finish the upload. The <img ...> lands in the textarea's
# live .value (NOT innerText, so `wait --text` won't see it) — poll with eval.
# In the DRAFT the src is github.com/user-attachments/... (the POSTED comment
# later renders from private-user-images.githubusercontent.com).
TA='textarea[placeholder=\"Use Markdown to format your comment\"]'
for i in $(seq 1 15); do
  pinchtab eval "document.querySelector('$TA').value" | grep -q "user-attachments" && break
  sleep 2
done

# 4. Submit — re-snap to get the *enabled* Comment button (its ref changes)
pinchtab snap | grep 'button "Comment"'
pinchtab click <comment-ref>

# 5. Verify it posted
#    draft cleared AND the last .markdown-body has an <img> from private-user-images
pinchtab eval '(() => { const b=[...document.querySelectorAll(".markdown-body")].pop();
  return b ? [...b.querySelectorAll("img")].map(i=>i.src)[0] || "no-img" : "no-body"; })()'
```

To attach to the **issue body** instead of a comment, run the same drop `eval`
while on `/issues/new` (the body editor uses the same
`textarea[placeholder="Use Markdown to format your comment"]`) before clicking
Create.

## PR path: attach to a pull request (verified — much simpler)

PR conversation pages still use GitHub's **classic editor**, which has a real
(hidden) `<input type="file">` — so `pinchtab upload` works directly; no eval,
no drop synthesis. Requires `security.allowUpload: true`.

```bash
pinchtab nav "https://github.com/$REPO/pull/<N>" --snap
pinchtab scroll 10000                    # comment box is at the bottom
pinchtab upload /tmp/shot.png -s "#fc-new_comment_field"
# wait for upload: <img ...> lands in the textarea value (same polling as issues)
pinchtab eval 'document.querySelector("#new_comment_field").value'   # expect user-attachments src
# add caption via native value setter if wanted, then re-snap and click "Comment"
```

Selectors (classic editor, stable ids): the comment box is
`textarea#new_comment_field` (`name="comment[body]"`), its file input is
`#fc-new_comment_field`. The input's `accept` list includes video
(`.mp4,.mov,.webm`) — video attachments work the same way.

If a PR page ever shows the React editor instead (no `input[type=file]`,
placeholder "Use Markdown to format your comment"), fall back to the issue
drop technique above — it works on both editors.

## Headless variant (headed → headless handoff)

Headless can post as long as the profile is already signed in — but the profile
can only be held by one instance at a time.

1. Sign in **once, headed**, in the dedicated profile (Preflight above).
2. **Stop that instance** to release the profile lock:
   `pinchtab instance stop <inst-id>` (id from `pinchtab instances`).
   > If you launch headless while the profile lock is still held, PinchTab
   > silently falls back to a throwaway temp profile — which is **not logged in**,
   > so issue creation/attachment fails.
3. Relaunch **headless on the same profile** — cookies persist, still signed in:
   ```bash
   pinchtab instance start --profile gh-<account> --mode headless
   ```
4. New session, then run the Minimal path unchanged. `screenshot --annotate`
   works fine headless.

## Gotchas / issues found

1. **No file input on issues — `pinchtab upload` cannot be used there
   (verified; PRs are the exception, see PR path).** The "Paste,
   drop, or click to add files" control opens a native OS picker; there is no
   `<input type=file>` in the DOM even *after* clicking it
   (`count input[type=file]` → 0), so `pinchtab upload -s "input[type=file]"`
   returns `404 element not found`. The only pinchtab-native path is the
   `pinchtab eval` file-drop shown in step 3. If the drop on the textarea alone
   doesn't take, also dispatch the same events on `ta.parentElement` and
   `ta.closest('div')`.
2. **Caption via `find`/`fill` is unreliable** — semantic `find` can return the
   feedback widget's textarea or a React wrapper. Target the comment box by
   `textarea[placeholder="Use Markdown to format your comment"]` and set the
   caption via the native value setter
   (`Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set`)
   + an `input` event so React keeps the change.
3. **Rendered image URL changes after posting.** In the draft the src is
   `github.com/user-attachments/assets/...`; once posted it renders from
   `private-user-images.githubusercontent.com`. Verification must accept both.
4. **`allowEvaluate` required.** The drop technique uses `pinchtab eval`; enable
   `security.allowEvaluate: true`.
5. **Comment button ref is not stable.** It starts disabled; re-snap after the
   draft has content to get the enabled ref.
6. **base64 payload size.** The image is embedded as base64 in the eval arg
   (~1.3× file size). Fine under macOS `ARG_MAX` (~1 MB); use
   `screenshot --scale 0.5` for very large captures.
7. **Domain allowlist.** `github.com` and the screenshot's host must be in
   `security.allowedDomains`.

## Possible PinchTab improvement (upstream)

`pinchtab upload` only does `DOM.setFileInputFiles` against an existing
`<input type=file>`. Modern React apps (GitHub issues) trigger a native file
chooser from a button with no persistent input, so `upload` cannot target them.
Worth adding upstream:
- `Page.setInterceptFileChooserDialog` support so `upload --click <button>`
  intercepts the native chooser, **or**
- a first-class `pinchtab upload --drop <selector> <file>` that dispatches the
  synthetic drop this skill does by hand.
